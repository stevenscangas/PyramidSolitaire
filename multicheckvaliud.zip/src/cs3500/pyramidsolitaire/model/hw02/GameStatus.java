package cs3500.pyramidsolitaire.model.hw02;

/**
 * This is an enumeration to represent the state of the game.
 */
public enum GameStatus {
  NOTSTARTED, STARTED

}
